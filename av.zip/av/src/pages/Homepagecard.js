// Contact.js
import React from 'react';
import MediaCard from './MediaCard.js';
import Img1 from '../pictures/pic4.jpg'
import Img2 from '../pictures/pic5.jpg'
import Img3 from '../pictures/pic6.jpg'
import { Box } from '@mui/material';
const Homepagecard = () => {
    const cardData = [
        { title: 'POTRAITS', date: 'September 14, 2016', image: Img1, buttonname:'See More',description: 'Portrait photography captures the essence of individuals, conveying their personality, emotions, and character through carefully composed images. Its an art form that immortalizes moments, showcasing the unique beauty and humanity of each subject.' },
        // Add more card data objects as needed
        { title: 'Nature', image: Img2, buttonname:'See More',description: 'Nature photography celebrates the majesty and intricacy of the natural world, inviting viewers to immerse themselves in its breathtaking landscapes and awe-inspiring details. Through the lens, it captures the raw beauty of our planet, fostering appreciation and stewardship for its diverse ecosystems.' },
        { title: 'Wedding', image: Img3,buttonname:'See More', description: 'Wedding photography encapsulates the timeless moments of love, joy, and commitment shared between couples on their special day, preserving memories to be cherished for generations. Through artful composition and candid captures, it immortalizes the emotions and connections that define the beginning of a lifelong journey together.'},
    ];
  return (
    <Box sx={{ width: '90%', position: 'absolute',marginTop: '20px' ,marginLeft:'45px', backgroundColor: '#f0f0f0', paddingBottom: '50px', overflow: 'hidden' }}>
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center',marginTop: '40px' }}>
      {cardData.map((card, index) => (
        <MediaCard
          key={index}
          title={card.title}
          image={card.image}
          buttonname={card.buttonname}
          description={card.description}
        />
      ))}
    </div>
    </Box>
    
  );
};

export default  Homepagecard;
