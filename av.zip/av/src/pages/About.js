import React, { useState } from 'react';
import Card from '@mui/material/Card';
import CardActionArea from '@mui/material/CardActionArea';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Box, Slider } from '@mui/material';
import Img1 from '../pictures/pic7.jpg'
import Img2 from '../pictures/pic6.jpg'
import Img3 from '../pictures/pic5.jpg'
import Img4 from '../pictures/pic4.jpg'
import Founder_1 from '../pictures/pic1.jpg'
import Founder_2 from '../pictures/pic2.JPG'
import Founder1_name from '../pictures/pic3.jpg'
import Founder2_name from '../pictures/pic7.jpg'

const About = () => {
  const [open, setOpen] = useState(false);
  const [scrollValue, setScrollValue] = useState(0);
  const [selectedCard, setSelectedCard] = useState(null);

  const cardContent = [
    { image: Img1, title: "Card 1", description: "Description of card 1" },
    { image: Img2, title: "Card 2", description: "Description of card 2" },
    { image: Img3, title: "Card 3", description: "Description of card 3" },
    { image: Img4, title: "Card 4", description: "Description of card 4" },
    { image: Img1, title: "Card 5", description: "Description of card 5" },
    { image: Img2, title: "Card 6", description: "Description of card 6" },
    { image: Img3, title: "Card 7", description: "Description of card 7" },
    { image: Img4, title: "Card 8", description: "Description of card 8" },
    { image: Img1, title: "Card 9", description: "Description of card 9" },
    { image: Img2, title: "Card 10", description: "Description of card 10" },
    // Add more card content here
  ];

  const handleClickOpen = (index) => {
    setOpen(true);
    setSelectedCard(index);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedCard(null);
  };

  const handleScrollChange = (event, newValue) => {
    setScrollValue(newValue);
  };

  return (<>
    <div style={{ display: 'flex', flexDirection: 'column', maxWidth: '100%', overflowX: 'hidden' }}>
      <div>
        <Card sx={{ maxWidth: 400 }} onClick={() => handleClickOpen(-1)}>
          <CardActionArea>
            <CardMedia
              component="img"
              height="300"
              image={Img1}
              alt="green iguana"
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                Satvik Rawal
              </Typography>
              <Typography variant="body2" color="text.secondary">
                A Skilled BeerBicepsSkillHouse Editor
              </Typography>
            </CardContent>
          </CardActionArea>
        </Card>
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>Larger View</DialogTitle>
          <DialogContent>
            <Card sx={{ maxWidth: 900 }}>
              <CardMedia
                component="img"
                height="300"
                width="500"
                image={(selectedCard !== null && cardContent[selectedCard]?.image) || Img1}
                alt={selectedCard !== null && cardContent[selectedCard]?.title} // Set the alt text to the title of the card
              />
              
              <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                  {selectedCard !== null && cardContent[selectedCard]?.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {selectedCard !== null && cardContent[selectedCard]?.description}
                </Typography>
              </CardContent>
            </Card>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
      <div style={{ position: 'relative', bottom: 350,left: 220, right: 1, padding: '10px', zIndex: 100  }}>
      <div style={{ position: 'right', bottom: 350, right: 90, padding: '10px', zIndex: 100 }}>
        <Typography variant="h6">Photography is my passion, a medium through
         which I weave stories, emotions,</Typography>
         <Typography variant="h6">and memories into timeless frames,<Typography variant="h6"> capturing the essence of life's fleeting moments.</Typography> <Typography variant="h6"></Typography>With each click of the shutter,
        I find solace and fulfillment,</Typography>
        <Typography variant="h6">  as my lens becomes a gateway to explore, </Typography><Typography variant="h6"> express, and celebrate the beauty of the world around me.</Typography>
      </div>
    </div>
      <Box sx={{ width: '100%', position: 'relative',marginTop: '20px' , backgroundColor: '#f0f0f0', paddingBottom: '50px', overflow: 'hidden' }}>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'row',
            overflowX: 'auto',
            scrollbarWidth: 'none', /* Hide scrollbar in Firefox */
            '-ms-overflow-style': 'none', /* Hide scrollbar in Edge */
            '&::-webkit-scrollbar': {
              display: 'none', /* Hide scrollbar in Chrome, Safari, and Opera */
            },
          }}
          style={{ transform: `translateX(-${scrollValue * 78}px)` }}
        >
          {cardContent.map((content, index) => (
            <Card key={index} sx={{ maxWidth: 200, margin: '10px' }} onClick={() => handleClickOpen(index)}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="80"
                  image={content.image}
                  alt="Placeholder"
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    {content.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {content.description}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          ))}
        </Box>
        <Box sx={{ position: 'absolute', bottom: 0, left: '50%', transform: 'translateX(-50%)', width: '60%' }}>
          <Slider
            aria-label="Scroll slider"
            defaultValue={0}
            value={scrollValue}
            onChange={handleScrollChange}
            step={1.0}
            marks
            min={0}
            max={10}
            valueLabelDisplay="auto"
            sx={{ mt: 1, width: '50%' }} // Adjust the width of the slider here
          />
        </Box>
      </Box>
      <br></br>
      <div style={{ display: 'flex', flexDirection: 'column', maxWidth: '100%', overflowX: 'hidden' }}>
      
        <Typography variant="h4" align="center" gutterBottom>
          History
        </Typography>
      
      <Typography variant="h5" gutterBottom style={{ marginTop: '20px' }}>
        In some Words
      </Typography>
      <Typography variant="body1">
      My journey in photography commenced with a simple fascination for capturing fleeting moments. Armed with a basic camera, I explored the world through its lens, discovering the art of storytelling in every frame. Over time, it evolved into a profound passion, a medium through which I express emotions, document memories, and celebrate the beauty of life.
          </Typography>
          <Typography variant="body1">
          My personal odyssey in photography began with a humble curiosity, sparked by the allure of freezing moments in time. Armed with a modest camera, I embarked on a voyage of exploration, eagerly capturing the world's beauty through my lens. Each click was not just a photograph but a fragment of a narrative, a glimpse into the emotions, stories, and memories that define our existence.
          </Typography>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img src={Founder_1} alt="Your " style={{ width: '30%', marginRight: '20px' }} />
       
        <div style={{ width: '100%' }}
      
        > <img src={Founder1_name} alt="Your " style={{ width: '40%', marginRight: '20px' ,marginTop:'70px'}} />
                    <Typography variant="body1">
                    My journey in photography commenced with a simple fascination for capturing fleeting moments. Armed with a basic camera, I explored the world through its lens, discovering the art of storytelling in every frame. Over time, it evolved into a profound passion, a medium through which I express emotions, document memories, and celebrate the beauty of life.
          </Typography>
          <Typography variant="body1">
          With each photograph, I found myself growing, evolving, and unraveling layers of creativity within. Whether capturing the raw beauty of nature, the intimate moments of human connection, or the vibrant tapestry of urban life, photography became my language, my means of connecting with the world and leaving a piece of myself behind.
          </Typography>
         
          <Typography variant="body1">
          Today, my journey in photography is an ongoing saga of self-discovery and expression. It's a testament to the power of art to transcend boundaries, touch hearts, and immortalize the beauty of fleeting moments in an ever-changing world.
          </Typography>
      </div>
      </div>
      
    </div>

    </div>
   

    </>
  );
};


export default About;
