import React from 'react';
import Typography from '@mui/material/Typography';
import Img1 from '../pictures/pic5.jpg'
import PropTypes from 'prop-types';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';


function TabPanel(props) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`full-width-tabpanel-${index}`}
        aria-labelledby={`full-width-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{ p: 3 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }
  
  TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
  };
  
  function a11yProps(index) {
    return {
      id: `full-width-tab-${index}`,
      'aria-controls': `full-width-tabpanel-${index}`,
    };
  }
  

const OurApproach = () => {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleChangeIndex = (index) => {
    setValue(index);
  };
  
  return (
    <div style={{ display: 'flex', flexDirection: 'column', maxWidth: '100%', overflowX: 'hidden' }}>
  
      <br></br>
      <div style={{ display: 'flex', flexDirection: 'column', maxWidth: '100%', overflowX: 'hidden' }}>
      
        <Typography variant="h3" align="centre" gutterBottom>
        Our Approach
        </Typography>
      
      <Typography variant="h5" align='centre' gutterBottom style={{ marginTop: '2px',marginLeft:'40px' }}>
        Our Approach Towards our Work
      </Typography>
      <div style={{ display: 'flex', alignItems: 'center' }}>
      <div style={{ width: '50%' ,marginTop:'20px'}}>
          <Typography variant="body1">
          In our approach to photography, we embrace the artistry and technical finesse inherent in every frame we capture. Each click of the shutter represents not just a moment frozen in time, but a narrative waiting to unfold. We believe in the power of visual storytelling, using our lenses to weave tales that resonate with emotion, depth, and authenticity.

Our work is guided by a passion for exploration, pushing the boundaries of creativity to discover unique perspectives and compositions. Whether we're photographing landscapes, portraits, or events, we approach each subject with a fresh perspective, seeking to uncover its essence and capture its essence in a single frame.


          </Typography>
          <Typography variant="body1">
          Technical proficiency is the backbone of our craft. We master the nuances of light, shadow, and composition, harnessing them to craft images that are not just visually striking but also conceptually profound. From the initial concept to the final edit, we pay meticulous attention to detail, ensuring that every aspect of the image aligns with our artistic vision.
          </Typography>
          <Box sx={{ bgcolor: 'background.paper', width: 500 ,marginTop:'20px',marginLeft:'50px'}}>
      <AppBar position="static">
        <Tabs
          value={value}
          onChange={handleChange}
          indicatorColor="secondary"
          textColor="inherit"
          variant="fullWidth"
          aria-label="full width tabs example"
        >
          <Tab label="Vision" {...a11yProps(0)} />
          <Tab label="Creativity" {...a11yProps(1)} />
          <Tab label="Professionalism" {...a11yProps(2)} />
        </Tabs>
      </AppBar>
      <SwipeableViews
        axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
        index={value}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={value} index={0} dir={theme.direction}>
          Vision which leads to a good project
        </TabPanel>
        <TabPanel value={value} index={1} dir={theme.direction}>
          Creativity that makes us find new ideas
        </TabPanel>
        <TabPanel value={value} index={2} dir={theme.direction}>
         Work Ethics which maintains professionalism in day-to-day life
        </TabPanel>
      </SwipeableViews>
    </Box>
      </div>
        <img src={Img1} alt="Your" style={{ width: '45%',height:'50%', marginLeft: '50px',marginTop:'5px'  }} />

      </div>
    </div>
</div>

  );
};


export default OurApproach;
