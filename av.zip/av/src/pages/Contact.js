// Contact.js
import React from 'react';
import RecipeReviewCard from './RecipeReviewCard';
import Img1 from '../pictures/pic4.jpg'
import Img2 from '../pictures/pic7.jpg'
import Img3 from '../pictures/pic3.jpg'


const Contact = () => {
    const cardData = [
        { title: 'Satvik', date: 'September 14, 2016', image: Img1, description: 'Based in Punjab, Banga', phone: '+123456789' },
        // Add more card data objects as needed
        { title: 'CVR', date: 'September 14, 2016', image:  Img2, description: 'Based In virtual reality', phone: '+987654321' },
        { title: 'Kartik', date: 'September 14, 2016', image:  Img3, description: 'Straight out of canada', phone: '+111222333' },
    ];
  return (
   <>
   <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
      {cardData.map((card, index,  ) => (
        <RecipeReviewCard
          key={index}
          title={card.title}
          subheader={card.date}
          image={card.image}
          description={card.description}
          phone={card.phone} // Pass phone number to RecipeReviewCard
        />
      ))}
    </div>
</>    
  );
};

export default Contact;
