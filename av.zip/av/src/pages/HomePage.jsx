import React from 'react';
import './HomePage.css';
import Jyoti_pic from '../pictures/pic3.jpg'
import Jyoti_1 from '../pictures/pic1.jpg' 
import Jyoti_2 from '../pictures/pic2.JPG' 
import Homepagecard from './Homepagecard';
import IntroDivider from './IntroDivider';
import SwipeableTextMobileStepper from './SwipeableTextMobileStepper'
import FixedBottomNavigation from './FixedBottomNavigation'
import AboutUs from './Aboutus';



// import SimpleSlider from './SimpleSlider';
// import ImageSlider from './ImageSlider';
// import { ImageData } from '../json/JsonData';


const HomePage = () => {
    

    return (
    <>
    <div className="homepage-background">
        <div className="text-container">
            <p className="animated-text">Your animated text here</p>
        </div>
    </div>
    <div className="content-container">
    <div className="img-group-container">
                <div className="img-group">
                    <div className="img-group-inner">
                        <img src={Jyoti_pic} alt="about" />
                        <span></span>
                        <span></span>
                    </div>
                    <img src={Jyoti_2} alt="about" />
                    <img src={Jyoti_1} alt="about" />
                </div>
            </div>
            <div className="article-1">
                <h2>Explore our Gallery </h2>
               <p>Step into our gallery and immerse yourself in a boundless visual journey meticulously crafted to evoke emotions that resonate deeply within. Each photograph housed within our curated collection is more than just an image; it's a narrative waiting to unfold, a glimpse into a moment frozen in time. From the delicate dance of light and shadow to the raw, unfiltered essence of human emotion, our gallery showcases a diverse tapestry of stories waiting to be discovered.

Every click of the shutter is a testament to the artistry and vision of our photographers, who capture the world through their unique perspectives, transforming the ordinary into the extraordinary. Whether it's the quiet serenity of a sunrise painting the sky in hues of gold and pink, or the frenetic energy of a bustling cityscape illuminated by neon lights, each photograph invites you to step closer, to linger a little longer, and to immerse yourself in the intricate details that make up the fabric of life.

As you navigate through our gallery, allow yourself to be transported to distant lands, to experience moments of joy, sorrow, wonder, and awe. Let the images speak to you, whispering stories of resilience, beauty, and the indomitable human spirit. Join us on this journey of exploration and discovery, where every photograph is a window to the soul, inviting you to see the world through a different lens.</p>
                {/* <p>Integer ac purus auctor, consequat velit id, suscipit mi. Duis nec lacinia lacus. Cras vitae elit vel justo consequat consectetur. Integer fermentum ligula ac odio luctus, sed gravida odio consequat. Suspendisse consectetur commodo massa, quis volutpat nisl venenatis ut. In a ligula dolor. Maecenas fringilla purus vitae urna volutpat, nec tempor orci sollicitudin. Sed vel nunc nec ipsum interdum suscipit id vel eros. Sed id sagittis mauris, vel iaculis odio. Morbi bibendum scelerisque pretium. Proin consequat ante in ipsum scelerisque, sit amet tempor nulla pellentesque.</p> */}
            </div>

    </div>
    <Homepagecard />
             
    
   
    </>
    );
};
export default HomePage;