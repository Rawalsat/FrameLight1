import './App.css';
import PersistentDrawerLeft from './pages/PersistentDrawerLeft';

function App() {
  return (
    <div className="App">
      <PersistentDrawerLeft></PersistentDrawerLeft>
    </div>
  );
}

export default App;
