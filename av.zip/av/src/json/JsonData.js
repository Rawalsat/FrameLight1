import Img1 from '../pictures/a.jpg'
import Img2 from '../pictures/b.jpg'
import Img3 from '../pictures/c.jpg'
import Img4 from '../pictures/d.jpg'
export const ImageData = [
    {
        ImageNo:'1/4',
        ImageName: 'mountains',
        ImageSrc: Img1
    },
    {
        ImageNo: '2/4',
        ImageName: 'img_nature',
        ImageSrc: Img2
    },
    {
        ImageNo: '3/4',
        ImageName: 'img_snow',
        ImageSrc: Img3
    },
    {
        ImageNo: '4/4',
        ImageName: 'img_band_ny',
        ImageSrc: Img4
    }
];